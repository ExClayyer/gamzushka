  const DADATA_API_KEY = '118ada5955e533a4a8bf1b661aae259dfa69ba0e';

  function calculateDistance() {
    const senderSuggestion = $('#senderAddress').data('suggestion');
    const receiverSuggestion = $('#receiverAddress').data('suggestion');
    
    const distanceBlock = document.getElementById('distanceBlock');
    const distanceResult = document.getElementById('distanceResult');
    if (!senderSuggestion || !receiverSuggestion) {
      distanceBlock.style.display = 'none';
      return;
    }

    const d1 = senderSuggestion.data;
    const d2 = receiverSuggestion.data;

    if (!d1.geo_lat || !d1.geo_lon || !d2.geo_lat || !d2.geo_lon) {
      distanceBlock.style.display = 'none';
      return;
    }

    distanceBlock.style.display = 'block';
    distanceResult.innerHTML = 'Считаем маршрут...';

    const url = 'https://router.project-osrm.org/route/v1/driving/' + 
                d1.geo_lon + ',' + d1.geo_lat + ';' + 
                d2.geo_lon + ',' + d2.geo_lat + '?overview=false';

    fetch(url)
      .then(function(response) {
        return response.json();
      })
      .then(function(data) {
        if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
          const meters = data.routes[0].distance;
          const km = (meters / 1000).toFixed(1);
          distanceResult.innerHTML = '~ ' + km + ' км';
        } else {
          distanceResult.innerHTML = 'Маршрут не найден';
        }
      })
      .catch(function(err) {
        console.error('Ошибка OSRM:', err);
        distanceResult.innerHTML = 'Ошибка расчета';
      });
  }

  const addressFields = '#senderAddress, #receiverAddress';
  
  $(addressFields).suggestions({
    token: DADATA_API_KEY,
    type: 'ADDRESS', 
    count: 7,          
    bounds: ['region', 'settlement', 'street', 'house'],
    constraints: {
      country: 'RU'  
    },
    restrict_value: true,

    onSelect: function(suggestion) {
      $(this).data('suggestion', suggestion);
      console.log('Выбранный адрес:', suggestion.value);
      
      calculateDistance();
    }
  });

  document.getElementById('shippingForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const rawSender = document.getElementById('senderAddress').value.trim();
    const senderSuggestion = $('#senderAddress').data('suggestion');
    let formattedSender = '';

    if (senderSuggestion) {
      const ds = senderSuggestion.data;
      const partsS = [];
      if (ds.region_with_type)    partsS.push(ds.region_with_type);
      if (ds.area_with_type)      partsS.push(ds.area_with_type);
      if (ds.settlement_with_type) partsS.push(ds.settlement_with_type);
      if (ds.street_with_type)    partsS.push(ds.street_with_type);
      if (ds.house)               partsS.push('д. ' + ds.house);
      
      formattedSender = partsS.join(', ');
    } else {
      formattedSender = rawSender;
    }

    const rawReceiver = document.getElementById('receiverAddress').value.trim();
    const receiverSuggestion = $('#receiverAddress').data('suggestion');
    let formattedReceiver = '';

    if (receiverSuggestion) {
      const dr = receiverSuggestion.data;
      const partsR = [];
      if (dr.region_with_type)    partsR.push(dr.region_with_type);
      if (dr.area_with_type)      partsR.push(dr.area_with_type);
      if (dr.settlement_with_type) partsR.push(dr.settlement_with_type);
      if (dr.street_with_type)    partsR.push(dr.street_with_type);
      if (dr.house)               partsR.push('д. ' + dr.house);
      
      formattedReceiver = partsR.join(', ');
    } else {
      formattedReceiver = rawReceiver;
    }
    
  });
