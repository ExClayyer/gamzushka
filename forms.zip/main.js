$(document).ready(function() {
    const isLegal = $('#senderIsLegal'); 
    const legalFields = $('#legalFields');
    legalFields.hide();

    isLegal.change(function() {
        if ($(this).is(':checked')) {
            legalFields.show();
        } else {
            legalFields.hide();
        }
    });

    function updateCost() {
        const distanceText = document.getElementById('distanceResult').innerText;
        const kmMatch = distanceText.match(/[\d\.]+/);
        const km = kmMatch ? parseFloat(kmMatch[0]) : 0;

        const distanceBlock = document.getElementById('distanceBlock');
        const costResult = document.getElementById('costResult');

        if (km === 0) {
            costResult.innerHTML = '—';
            return;
        }

        const tariffSelect = document.getElementById('shippingTariff');
        const rate = parseFloat(tariffSelect.options[tariffSelect.selectedIndex].getAttribute('data-rate')) || 15;

        const l = parseFloat(document.getElementById('dimLength').value) || 0;
        const w = parseFloat(document.getElementById('dimWidth').value) || 0;
        const h = parseFloat(document.getElementById('dimHeight').value) || 0;

        let coef = (l * w * h) / 10000;
        if (coef < 1) coef = 1;

        const cost = Math.round(km * rate * coef);
        costResult.innerHTML = cost.toLocaleString('ru-RU') + ' ₽';

        distanceBlock.dataset.km = km;
        distanceBlock.dataset.cost = cost;
        distanceBlock.dataset.coef = coef.toFixed(2);
        distanceBlock.dataset.rate = rate;
    }

    $('#shippingTariff, #dimLength, #dimWidth, #dimHeight').on('change input', function() {
        updateCost();
    });

    document.getElementById('shippingForm').addEventListener('submit', function(e) {
        e.preventDefault();
        updateCost();

        const distanceBlock = document.getElementById('distanceBlock');
        const km = distanceBlock.dataset.km || 'Не рассчитано';
        const cost = distanceBlock.dataset.cost || 'Не рассчитано';
        const coef = distanceBlock.dataset.coef || '1.00';
        const rate = distanceBlock.dataset.rate || '15';

        const senderFIO = `${document.getElementById('senderLastName').value} ${document.getElementById('senderFirstName').value} ${document.getElementById('senderMiddleName').value}`.trim();
        const senderPass = `${document.getElementById('senderPassSerial').value} ${document.getElementById('senderPassNumber').value}`.trim();
        const senderPhone = document.getElementById('senderPhone').value;
        
        const senderSuggestion = $('#senderAddress').data('suggestion');
        const formattedSender = senderSuggestion ? senderSuggestion.unrestricted_value : document.getElementById('senderAddress').value.trim();

        let senderLegalInfo = '';
        if (document.getElementById('senderIsLegal').checked) {
            const companyName = document.getElementById('senderCompanyName').value;
            const inn = document.getElementById('senderINN').value;
            senderLegalInfo = `<p><b>Компания:</b> ${companyName || '—'}</p><p><b>ИНН:</b> ${inn || '—'}</p>`;
        }

        const receiverFIO = `${document.getElementById('receiverLastName').value} ${document.getElementById('receiverFirstName').value} ${document.getElementById('receiverMiddleName').value}`.trim();
        const receiverPass = `${document.getElementById('receiverPassSerial').value} ${document.getElementById('receiverPassNumber').value}`.trim();
        const receiverPhone = document.getElementById('receiverPhone').value;
        
        const receiverSuggestion = $('#receiverAddress').data('suggestion');
        const formattedReceiver = receiverSuggestion ? receiverSuggestion.unrestricted_value : document.getElementById('receiverAddress').value.trim();

        const shipmentName = document.getElementById('shipmentName').value;
        const weight = `${document.getElementById('shipmentWeight').value} ${document.getElementById('shipmentWeightUnit').value}`;
        const dimensions = `${document.getElementById('dimLength').value} × ${document.getElementById('dimWidth').value} × ${document.getElementById('dimHeight').value} см`;

        const tariffSelect = document.getElementById('shippingTariff');
        const tariffName = tariffSelect.options[tariffSelect.selectedIndex].text;

        const summaryHTML = `
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
            <div style="background: #f8f9fa; padding: 15px; border-radius: 4px;">
              <h3 style="margin-top: 0; color: #495057;">Отправитель</h3>
              <p><b>ФИО:</b> ${senderFIO || '—'}</p>
              <p><b>Паспорт:</b> ${senderPass || '—'}</p>
              <p><b>Телефон:</b> ${senderPhone || '—'}</p>
              <p><b>Адрес:</b> ${formattedSender || '—'}</p>
              ${senderLegalInfo}
            </div>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 4px;">
              <h3 style="margin-top: 0; color: #495057;">Получатель</h3>
              <p><b>ФИО:</b> ${receiverFIO || '—'}</p>
              <p><b>Паспорт:</b> ${receiverPass || '—'}</p>
              <p><b>Телефон:</b> ${receiverPhone || '—'}</p>
              <p><b>Адрес:</b> ${formattedReceiver || '—'}</p>
            </div>
          </div>
          
          <div style="background: #e9ecef; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #495057;">Параметры отправления</h3>
            <p><b>Название:</b> ${shipmentName}</p>
            <p><b>Вес:</b> ${weight}</p>
            <p><b>Габариты (Д×Ш×В):</b> ${dimensions}</p>
            <p><b>Тариф:</b> ${tariffName}</p>
          </div>

          <div style="background: #d1e7dd; padding: 15px; border-radius: 4px; border: 1px solid #badbcc;">
            <h3 style="margin-top: 0; color: #0f5132;">Расчет стоимости</h3>
            <p><b>Расстояние:</b> ${km} км</p>
            <p><b>Формула:</b> ${km} км × ${rate} ₽/км × Коэфф. габаритов (${coef})</p>
            <p style="font-size: 1.4em; font-weight: bold; color: #157347; margin-top: 10px;">ИТОГО К ОПЛАТЕ: ${Number(cost).toLocaleString('ru-RU')} ₽</p>
          </div>
        `;

        document.getElementById('summaryContent').innerHTML = summaryHTML;
        document.getElementById('applicationSummary').style.display = 'block';
        document.getElementById('applicationSummary').scrollIntoView({ behavior: 'smooth' });
    });
});